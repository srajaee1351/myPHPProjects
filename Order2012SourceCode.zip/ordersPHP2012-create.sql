SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

DROP SCHEMA IF EXISTS `ordersPHP2012` ;
CREATE SCHEMA IF NOT EXISTS `ordersPHP2012` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
USE `ordersPHP2012` ;

-- -----------------------------------------------------
-- Table `ordersPHP2012`.`tblSalesRep`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ordersPHP2012`.`tblSalesRep` ;

CREATE  TABLE IF NOT EXISTS `ordersPHP2012`.`tblSalesRep` (
  `salesRepID` INT NOT NULL ,
  `firstName` VARCHAR(45) NOT NULL ,
  `lastName` VARCHAR(45) NOT NULL ,
  `commisionRate` FLOAT NOT NULL ,
  PRIMARY KEY (`salesRepID`) )
ENGINE = INNODB;


-- -----------------------------------------------------
-- Table `ordersPHP2012`.`tblCustomer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ordersPHP2012`.`tblCustomer` ;

CREATE  TABLE IF NOT EXISTS `ordersPHP2012`.`tblCustomer` (
  `customerID` INT NOT NULL ,
  `salesRepID` INT NOT NULL ,
  `customerName` VARCHAR(45) NOT NULL ,
  `streetAddress` VARCHAR(45) NOT NULL ,
  `suburb` VARCHAR(45) NOT NULL ,
  `state` VARCHAR(45) NOT NULL ,
  `postCode` VARCHAR(45) NOT NULL ,
   PRIMARY KEY (`customerID`) ,
  UNIQUE INDEX `customerID_UNIQUE` (`customerID` ASC) ,
  INDEX `fk_tblCustomer_tblSalesRep1` (`salesRepID` ASC) ,
  CONSTRAINT `fk_tblCustomer_tblSalesRep1`
    FOREIGN KEY (`salesRepID` )
    REFERENCES `ordersPHP2012`.`tblSalesRep` (`salesRepID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = INNODB;


-- -----------------------------------------------------
-- Table `ordersPHP2012`.`tblOrder`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ordersPHP2012`.`tblOrder` ;

CREATE  TABLE IF NOT EXISTS `ordersPHP2012`.`tblOrder` (
  `orderID` INT NOT NULL ,
  `customerID` INT NOT NULL ,
  `dateCreated` DATE NOT NULL ,
  PRIMARY KEY (`orderID`) ,
  UNIQUE INDEX `orderID_UNIQUE` (`orderID` ASC) ,
  INDEX `fk_tblOrder_tblCustomer1` (`customerID` ASC) ,
  CONSTRAINT `fk_tblOrder_tblCustomer1`
    FOREIGN KEY (`customerID` )
    REFERENCES `ordersPHP2012`.`tblCustomer` (`customerID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = INNODB;


-- -----------------------------------------------------
-- Table `ordersPHP2012`.`tblParts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ordersPHP2012`.`tblParts` ;

CREATE  TABLE IF NOT EXISTS `ordersPHP2012`.`tblParts` (
  `partID` INT NOT NULL ,
  `partDescription` VARCHAR(45) NOT NULL ,
  `price` FLOAT NOT NULL ,
  `quantityOnHand` INT NOT NULL ,
  PRIMARY KEY (`partID`) ,
  UNIQUE INDEX `partID_UNIQUE` (`partID` ASC) )
ENGINE = INNODB;


-- -----------------------------------------------------
-- Table `ordersPHP2012`.`tblInvoice`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ordersPHP2012`.`tblInvoice` ;

CREATE  TABLE IF NOT EXISTS `ordersPHP2012`.`tblInvoice` (
  `orderID` INT NOT NULL ,
  `partID` INT NOT NULL ,
  `quantity` INT NULL ,
  PRIMARY KEY (`orderID`, `partID`) ,
  INDEX `fk_tblOrder_has_tblParts_tblParts1` (`partID` ASC) ,
  INDEX `fk_tblOrder_has_tblParts_tblOrder1` (`orderID` ASC) ,
  CONSTRAINT `fk_tblOrder_has_tblParts_tblOrder1`
    FOREIGN KEY (`orderID` )
    REFERENCES `ordersPHP2012`.`tblOrder` (`orderID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tblOrder_has_tblParts_tblParts1`
    FOREIGN KEY (`partID` )
    REFERENCES `ordersPHP2012`.`tblParts` (`partID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = INNODB;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


-- -----------------------------------------------------
-- Insert Table `ordersPHP2012`.`tblSalesRep`
-- -----------------------------------------------------
INSERT INTO `ordersPHP2012`.`tblSalesRep` 
	(`salesRepID`, 
	`firstName`,
	`lastName`,
	`commisionRate`
	)
	VALUES
	('300', 
	'Peter',
	'Provis',
	'0.05'
	);
INSERT INTO `ordersPHP2012`.`tblSalesRep` 
	(`salesRepID`, 
	`firstName`,
	`lastName`,
	`commisionRate`
	)
	VALUES
	('301', 
	'Kim',
	'Ng',
	'0.05'
	);
INSERT INTO `ordersPHP2012`.`tblSalesRep` 
	(`salesRepID`, 
	`firstName`,
	`lastName`,
	`commisionRate`
	)
	VALUES
	('302', 
	'Lara',
	'Beable',
	'0.08'
	);
INSERT INTO `ordersPHP2012`.`tblSalesRep` 
	(`salesRepID`, 
	`firstName`,
	`lastName`,
	`commisionRate`
	)
	VALUES
	('303', 
	'Lydia',
	'Smyth-Jones',
	'0.10'
	);
	
-- -----------------------------------------------------
-- Insert Table `ordersPHP2012`.`tblcustomer`
-- -----------------------------------------------------	
INSERT INTO `ordersphp2012`.`tblcustomer` 
	(`customerID`, 
	`salesRepID`, 
	`customerName`, 
	`streetAddress`, 
	`suburb`, 
	`state`, 
	`postCode`
	)
	VALUES
	('30', 
	'300', 
	'Alex Lifeson', 
	'45 By-Tor Way', 
	'Box Hill', 
	'VIC', 
	'3128'
	);

INSERT INTO `ordersphp2012`.`tblcustomer` 
	(`customerID`, 
	`salesRepID`, 
	`customerName`, 
	`streetAddress`, 
	`suburb`, 
	`state`, 
	`postCode`
	)
	VALUES
	('31', 
	'302', 
	'Geddy Lee', 
	'78 Moving Pictures Lane', 
	'Box Hill', 
	'VIC', 
	'3128'
	);	

INSERT INTO `ordersphp2012`.`tblcustomer` 
	(`customerID`, 
	`salesRepID`, 
	`customerName`, 
	`streetAddress`, 
	`suburb`, 
	`state`, 
	`postCode`
	)
	VALUES
	('32', 
	'302', 
	'Boz Scaggs', 
	'6 Lido Shuffle Court', 
	'Mitcham', 
	'VIC', 
	'3123'
	);		

INSERT INTO `ordersphp2012`.`tblcustomer` 
	(`customerID`, 
	`salesRepID`, 
	`customerName`, 
	`streetAddress`, 
	`suburb`, 
	`state`, 
	`postCode`
	)
	VALUES
	('33', 
	'302', 
	'Cindy Smalls', 
	'900 Station Street', 
	'Blackburn', 
	'VIC', 
	'3130'
	);	
	
INSERT INTO `ordersphp2012`.`tblcustomer` 
	(`customerID`, 
	`salesRepID`, 
	`customerName`, 
	`streetAddress`, 
	`suburb`, 
	`state`, 
	`postCode`
	)
	VALUES
	('34', 
	'303', 
	'Tina Bigguns', 
	'78 Willie Parade', 
	'Blackburn', 
	'VIC', 
	'3130'
	);	
	
INSERT INTO `ordersphp2012`.`tblcustomer` 
	(`customerID`, 
	`salesRepID`, 
	`customerName`, 
	`streetAddress`, 
	`suburb`, 
	`state`, 
	`postCode`
	)
	VALUES
	('35', 
	'303', 
	'Jimmy Smith', 
	'66 Hagis Roade', 
	'Mitcham', 
	'VIC', 
	'3123'
	);	
	
-- -----------------------------------------------------
-- Insert Table `ordersPHP2012`.`tblOrder`
-- -----------------------------------------------------
INSERT INTO `ordersphp2012`.`tblorder` 
	(`orderID`, 
	`customerID`, 
	`dateCreated`
	)
	VALUES
	('10010', 
	'31', 
	'2011-07-04'
	);

INSERT INTO `ordersphp2012`.`tblorder` 
	(`orderID`, 
	`customerID`, 
	`dateCreated`
	)
	VALUES
	('10011', 
	'32', 
	'2011-06-12'
	);
	
INSERT INTO `ordersphp2012`.`tblorder` 
	(`orderID`, 
	`customerID`, 
	`dateCreated`
	)
	VALUES
	('10012', 
	'35', 
	'2011-06-12'
	);
	
INSERT INTO `ordersphp2012`.`tblorder` 
	(`orderID`, 
	`customerID`, 
	`dateCreated`
	)
	VALUES
	('10013', 
	'30', 
	'2011-06-05'
	);
	
INSERT INTO `ordersphp2012`.`tblorder` 
	(`orderID`, 
	`customerID`, 
	`dateCreated`
	)
	VALUES
	('10014', 
	'33', 
	'2011-07-04'
	);
	
INSERT INTO `ordersphp2012`.`tblorder` 
	(`orderID`, 
	`customerID`, 
	`dateCreated`
	)
	VALUES
	('10015', 
	'31', 
	'2011-07-05'
	);
	
INSERT INTO `ordersphp2012`.`tblorder` 
	(`orderID`, 
	`customerID`, 
	`dateCreated`
	)
	VALUES
	('10016', 
	'30', 
	'2011-06-06'
	);
-- -----------------------------------------------------
-- Insert Table `ordersPHP2012`.`tblParts`
-- -----------------------------------------------------	

INSERT INTO `ordersphp2012`.`tblparts` 
	(`partID`, 
	`partDescription`, 
	`price`, 
	`quantityOnHand`
	)
	VALUES
	('950', 
	'0.5cm Nut', 
	'0.10', 
	'900'
	);

INSERT INTO `ordersphp2012`.`tblparts` 
	(`partID`, 
	`partDescription`, 
	`price`, 
	`quantityOnHand`
	)
	VALUES
	('951', 
	'0.95cm Bolt', 
	'0.25', 
	'450'
	);	
INSERT INTO `ordersphp2012`.`tblparts` 
	(`partID`, 
	`partDescription`, 
	`price`, 
	`quantityOnHand`
	)
	VALUES
	('952', 
	'1.5cm Screw', 
	'1.00', 
	'760'
	);	
	
INSERT INTO `ordersphp2012`.`tblparts` 
	(`partID`, 
	`partDescription`, 
	`price`, 
	`quantityOnHand`
	)
	VALUES
	('953', 
	'2.0cm Bolt', 
	'1.15', 
	'490'
	);
	
INSERT INTO `ordersphp2012`.`tblparts` 
	(`partID`, 
	`partDescription`, 
	`price`, 
	`quantityOnHand`
	)
	VALUES
	('954', 
	'3.0cm Dynabolt', 
	'3.20', 
	'300'
	);
	
INSERT INTO `ordersphp2012`.`tblparts` 
	(`partID`, 
	`partDescription`, 
	`price`, 
	`quantityOnHand`
	)
	VALUES
	('955', 
	'4.5cm Hex Bolt', 
	'2.50', 
	'200'
	);

